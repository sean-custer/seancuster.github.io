function function_name(argument) {
	// body..
}